﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BradyConsoleApp2.Program;

namespace BradyConsoleApp2
{
    public class FolderWatcher
    {
        private List<string> getwindlist = new List<string>();
        private List<string> getgaslist = new List<string>();
        private List<string> getcoallist = new List<string>();
        public void getLatestFileFromWatchedFolder() {
            string path = ConfigurationManager.AppSettings["Path"];
            using var watcher = new FileSystemWatcher(@path);
            //Properties used for monitoring changes
            watcher.NotifyFilter = NotifyFilters.Attributes
                                 | NotifyFilters.CreationTime
                                 | NotifyFilters.DirectoryName
                                 | NotifyFilters.FileName
                                 | NotifyFilters.LastWrite
                                 | NotifyFilters.Security
                                 | NotifyFilters.Size;

            //Event for monitoring on creation
            watcher.Created += OnCreated;

            //Searching for that specific file for monitoring 
            watcher.Filter = "01-Basic.xml";

            watcher.IncludeSubdirectories = false;
            watcher.EnableRaisingEvents = true;

            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();

            void OnCreated(object sender, FileSystemEventArgs e)
            {
                XmlUnilities xmlUnilities = new XmlUnilities();
                getwindlist = xmlUnilities.getWindValuesFromXml();
                getgaslist = xmlUnilities.getGasValuesFromXml();
                getcoallist = xmlUnilities.getCoalValuesFromXml();
                int windkey = 0;
                int gaskey = 0;
                int coalkey = 0;
                Dictionary<int, string> winddic = new Dictionary<int, string>();
                Dictionary<int, string> gasdic = new Dictionary<int, string>();
                Dictionary<int, string> coaldic = new Dictionary<int, string>();
                foreach (string wind in getwindlist)
                {
                    windkey++;
                    winddic.Add(windkey, wind);                  
                }
                Console.WriteLine(winddic[1] + "Printed by key");

                foreach (string gas in gasdic.Values)
                {
                    gaskey++;
                    gasdic.Add(gaskey, gas);
                }
                Console.WriteLine(gasdic[2] + "Printed by key");

                foreach (string coal in coaldic.Values)
                {
                    coalkey++;
                    coaldic.Add(coalkey, coal);
                }
                Console.WriteLine(gasdic[3] + "Printed by key");
            }
        }
    }
}
