﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BradyConsoleApp2
{
    public class XmlUnilities
    {
        List<string> windlist = new List<string>();
        List<string> gaslist = new List<string>();
        List<string> coallist = new List<string>();
        XmlDocument doc = new XmlDocument();
        public XmlUnilities() {
            doc.PreserveWhitespace = true;
            try
            {
                string path = ConfigurationManager.AppSettings["Path"];
                doc.Load(path + @"\01-Basic.xml");
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("File not found!");
            }
        }
        public List<string> getWindValuesFromXml() {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Wind/WindGenerator");
       
            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    windlist.Add(node2.SelectSingleNode("Date").InnerText);
                    windlist.Add(node2.SelectSingleNode("Energy").InnerText);
                    windlist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            return windlist;
        }

        public List<string> getGasValuesFromXml()
        {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Gas/GasGenerator");

            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    gaslist.Add(node2.SelectSingleNode("Date").InnerText);
                    gaslist.Add(node2.SelectSingleNode("Energy").InnerText);
                    gaslist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            XmlNodeList emisions = doc.DocumentElement.SelectNodes("/GenerationReport/Gas/GasGenerator");
            foreach (XmlNode emision in emisions) {
                gaslist.Add(emision.SelectSingleNode("EmissionsRating").InnerText);
            }
            return gaslist;
        }

        public List<string> getCoalValuesFromXml()
        {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Coal/CoalGenerator");

            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    coallist.Add(node2.SelectSingleNode("Date").InnerText);
                    coallist.Add(node2.SelectSingleNode("Energy").InnerText);
                    coallist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            XmlNodeList emisions = doc.DocumentElement.SelectNodes("/GenerationReport/Coal/CoalGenerator");
            foreach (XmlNode emision in emisions)
            {
                coallist.Add(emision.SelectSingleNode("EmissionsRating").InnerText);
            }
            return coallist;
        }
    }
}