﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BradyConsoleApp2
{
    public class XmlUnilities
    {
        public static void readNewXml()
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.PreserveWhitespace = true;
            try
            {
                xmlDoc.Load(@"E:\Vizrt Product Installers\April 2022\Brady Code Challenge - ETRM - June 2021\Brady Code Challenge_June 2021\01-Basic.xml");
                Console.WriteLine(xmlDoc.DocumentElement.OuterXml);
          
            }
            catch (System.IO.FileNotFoundException)
            {
               
            }
        }

        public static void getValuesFromXml() {
            List<string> list1 = new List<string>();

            XmlDocument doc = new XmlDocument();
            doc.PreserveWhitespace = true;
            try
            {
                doc.Load(@"E:\Vizrt Product Installers\April 2022\Brady Code Challenge - ETRM - June 2021\Brady Code Challenge_June 2021\01-Basic.xml");
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("File not found!");
            }
            
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Wind/WindGenerator");
       
            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");
                string date = "", energy = "", price = "";
                foreach (XmlNode node2 in name)
                { 
                    list1.Add(node2.SelectSingleNode("Date").InnerText);
                    list1.Add(node2.SelectSingleNode("Energy").InnerText);
                    list1.Add(node2.SelectSingleNode("Price").InnerText);

                }

            }
            foreach (string i in list1)
            {
                Console.WriteLine(i);
            }

        }
    }
}