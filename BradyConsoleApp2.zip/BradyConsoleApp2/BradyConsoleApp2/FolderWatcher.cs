﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BradyConsoleApp2
{
    public class FolderWatcher
    {
        public static Dictionary<string, string> latestXML;
        public static void getLatestFileFromWatchedFolder() {
            using var watcher = new FileSystemWatcher(@"E:\Vizrt Product Installers\April 2022\Brady Code Challenge - ETRM - June 2021\Brady Code Challenge_June 2021");
            //Properties used for monitoring changes
            watcher.NotifyFilter = NotifyFilters.Attributes
                                 | NotifyFilters.CreationTime
                                 | NotifyFilters.DirectoryName
                                 | NotifyFilters.FileName
                                 | NotifyFilters.LastWrite
                                 | NotifyFilters.Security
                                 | NotifyFilters.Size;

            //Event for monitoring on creation
            watcher.Created += OnCreated;

            //Searching for that specific file for monitoring 
            watcher.Filter = "01-Basic.xml";

            watcher.IncludeSubdirectories = false;
            watcher.EnableRaisingEvents = true;

            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();

            void OnCreated(object sender, FileSystemEventArgs e)
            {
                XmlUnilities.getValuesFromXml();
            }
        }
    }
}
