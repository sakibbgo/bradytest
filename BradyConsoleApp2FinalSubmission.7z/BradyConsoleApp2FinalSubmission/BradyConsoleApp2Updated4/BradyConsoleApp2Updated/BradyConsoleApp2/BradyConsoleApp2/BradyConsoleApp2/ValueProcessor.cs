﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BradyConsoleApp2.Program;

namespace BradyConsoleApp2
{
    public class ValueProcessor
    {
        public ValueProcessor() { 
        
        }
        public double getTotalGenerationPerDay(double price, double energy, double valuefactor) {
            return price * energy * valuefactor;
        }

        public double getTotalEmissionPerday(double energy, double emissionrating, double emissionfactor) { 
            return energy * emissionrating * emissionfactor;    
        }

        public double gettotalwindoffshore(Dictionary<int, string> winddic, Dictionary<int, string> gasdic, Dictionary<int, string> coaldic) {
            return getTotalGenerationPerDay(Convert.ToDouble(winddic[3]), Convert.ToDouble(winddic[2]), References.offshorewindlow) +
            getTotalGenerationPerDay(Convert.ToDouble(winddic[6]), Convert.ToDouble(winddic[5]), References.offshorewindlow) +
            getTotalGenerationPerDay(Convert.ToDouble(winddic[9]), Convert.ToDouble(winddic[8]), References.offshorewindlow);
        }

        public double gettotalwindonshore(Dictionary<int, string> winddic, Dictionary<int, string> gasdic, Dictionary<int, string> coaldic)
        {
            return getTotalGenerationPerDay(Convert.ToDouble(winddic[12]), Convert.ToDouble(winddic[11]), References.onshorewindhigh) +
                   getTotalGenerationPerDay(Convert.ToDouble(winddic[15]), Convert.ToDouble(winddic[14]), References.onshorewindhigh) +
                   getTotalGenerationPerDay(Convert.ToDouble(winddic[18]), Convert.ToDouble(winddic[17]), References.onshorewindhigh);
        }

        public double gettotalgas(Dictionary<int, string> winddic, Dictionary<int, string> gasdic, Dictionary<int, string> coaldic)
        {
            return getTotalGenerationPerDay(Convert.ToDouble(gasdic[3]), Convert.ToDouble(gasdic[2]), References.gasmedium) +
                   getTotalGenerationPerDay(Convert.ToDouble(gasdic[6]), Convert.ToDouble(gasdic[5]), References.gasmedium) +
                   getTotalGenerationPerDay(Convert.ToDouble(gasdic[9]), Convert.ToDouble(gasdic[8]), References.gasmedium);
        }

        public double gettotalcoal(Dictionary<int, string> winddic, Dictionary<int, string> gasdic, Dictionary<int, string> coaldic)
        {
            return getTotalGenerationPerDay(Convert.ToDouble(coaldic[3]), Convert.ToDouble(coaldic[2]), References.coalmedium) +
                   getTotalGenerationPerDay(Convert.ToDouble(coaldic[6]), Convert.ToDouble(coaldic[5]), References.coalmedium) +
                   getTotalGenerationPerDay(Convert.ToDouble(coaldic[9]), Convert.ToDouble(coaldic[8]), References.coalmedium);
        }


    }
}
