﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BradyConsoleApp2
{
    public class XmlUtilities
    {
        List<string> windlist = new List<string>();
        List<string> gaslist = new List<string>();
        List<string> coallist = new List<string>();
        XmlDocument doc = new XmlDocument();
        public XmlUtilities() {
            doc.PreserveWhitespace = true;
            try
            {
                string path = ConfigurationManager.AppSettings["inputPath"];
                doc.Load(path + @"\01-Basic.xml");
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("File not found!");
            }
        }
        public List<string> getWindValuesFromXml() {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Wind/WindGenerator");
       
            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    windlist.Add(node2.SelectSingleNode("Date").InnerText);
                    windlist.Add(node2.SelectSingleNode("Energy").InnerText);
                    windlist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            return windlist;
        }

        public List<string> getGasValuesFromXml()
        {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Gas/GasGenerator");

            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    gaslist.Add(node2.SelectSingleNode("Date").InnerText);
                    gaslist.Add(node2.SelectSingleNode("Energy").InnerText);
                    gaslist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            XmlNodeList emisions = doc.DocumentElement.SelectNodes("/GenerationReport/Gas/GasGenerator");
            foreach (XmlNode emision in emisions) {
                gaslist.Add(emision.SelectSingleNode("EmissionsRating").InnerText);
            }
            return gaslist;
        }

        public List<string> getCoalValuesFromXml()
        {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Coal/CoalGenerator");

            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    coallist.Add(node2.SelectSingleNode("Date").InnerText);
                    coallist.Add(node2.SelectSingleNode("Energy").InnerText);
                    coallist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            XmlNodeList emisions = doc.DocumentElement.SelectNodes("/GenerationReport/Coal/CoalGenerator");
            foreach (XmlNode emision in emisions)
            {
                coallist.Add(emision.SelectSingleNode("EmissionsRating").InnerText);
                coallist.Add(emision.SelectSingleNode("TotalHeatInput").InnerText);
                coallist.Add(emision.SelectSingleNode("ActualNetGeneration").InnerText);
            }
            return coallist;
        }

        //11 param
        public void generateXmlFile(double totalwindoffshore, double totalwindonshore, double totalgas, double totalcoal, string day1emission, string day2emission, string day3emission, double heatrate, string dateday1, string dateday2, string dateday3)
        {
            XmlDocument doc = new XmlDocument();
            string day1emisstionname;
            string day2emisstionname;
            string day3emisstionname;
            if (day1emission.Contains("gas")){
                day1emisstionname = "Gas[1]";
                day1emission = day1emission.Remove(day1emission.Length - 3, 3);
            }
            else{
                day1emisstionname = "Coal[1]";
            }

            if (day2emission.Contains("gas"))
            {
                day2emisstionname = "Gas[1]";
                day2emission = day2emission.Remove(day2emission.Length - 3, 3);
            }
            else
            {
                day2emisstionname = "Coal[1]";
            }

            if (day3emission.Contains("gas"))
            {
                day3emisstionname = "Gas[1]";
                day3emission = day3emission.Remove(day3emission.Length -3, 3);
            }
            else
            {
                day3emisstionname = "Coal[1]";
            }


           
            XmlDeclaration xmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            XmlElement root = doc.DocumentElement;
            doc.InsertBefore(xmlDeclaration, root);

            

            //Root node
            XmlElement rootnode = doc.CreateElement(string.Empty, "GenerationOutput", string.Empty);
            doc.AppendChild(rootnode);

            rootnode.SetAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
            rootnode.SetAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");

            XmlElement totalsnode = doc.CreateElement(string.Empty, "Totals", string.Empty);
            rootnode.AppendChild(totalsnode);

            //winoffshore generator 
            XmlElement generatornode1 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode1);

            XmlElement windoffnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode1.AppendChild(windoffnamenode);
            XmlText namewinoffshore = doc.CreateTextNode("Wind[Offshore]");
            windoffnamenode.AppendChild(namewinoffshore);
            
            XmlElement windofftotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode1.AppendChild(windofftotalnode);
            XmlText valuewindoffshore = doc.CreateTextNode(Convert.ToString(totalwindoffshore));
            windofftotalnode.AppendChild(valuewindoffshore);

            //winonshore generator
            XmlElement generatornode2 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode2);

            XmlElement windonnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode2.AppendChild(windonnamenode);
            XmlText namewinonshore = doc.CreateTextNode("Wind[Onshore]");
            windonnamenode.AppendChild(namewinonshore);

            XmlElement wintonotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode2.AppendChild(wintonotalnode);
            XmlText valuewinonshore = doc.CreateTextNode(Convert.ToString(totalwindonshore));
            wintonotalnode.AppendChild(valuewinonshore);

            //gas generator
            XmlElement generatornode3 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode3);

            XmlElement gasnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode3.AppendChild(gasnamenode);
            XmlText namegas = doc.CreateTextNode("Gas[1]");
            gasnamenode.AppendChild(namegas);

            XmlElement gastotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode3.AppendChild(gastotalnode);
            XmlText valuegas = doc.CreateTextNode(Convert.ToString(totalgas));
            gastotalnode.AppendChild(valuegas);

            //coal generator 
            XmlElement generatornode4 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode4);

            XmlElement coalnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode4.AppendChild(coalnamenode);
            XmlText namecoal = doc.CreateTextNode("Coal[1]");
            coalnamenode.AppendChild(namecoal);

            XmlElement coaltotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode4.AppendChild(coaltotalnode);
            XmlText valuecoal = doc.CreateTextNode(Convert.ToString(totalcoal));
            coaltotalnode.AppendChild(valuecoal);

            
            XmlElement maxemissionnode = doc.CreateElement(string.Empty, "MaxEmissionGenerators", string.Empty);
            rootnode.AppendChild(maxemissionnode);

            //Max emission node day1
            XmlElement day1node = doc.CreateElement(string.Empty, "Day", string.Empty);
            maxemissionnode.AppendChild(day1node);
            XmlElement day1name = doc.CreateElement(string.Empty, "Name", string.Empty);
            day1node.AppendChild(day1name);
            XmlText day1nametext = doc.CreateTextNode(day1emisstionname);
            day1name.AppendChild(day1nametext);
            XmlElement day1datenode = doc.CreateElement(string.Empty, "Date", string.Empty);
            day1node.AppendChild(day1datenode);
            XmlText day1datetext = doc.CreateTextNode(dateday1);
            day1datenode.AppendChild(day1datetext);
            XmlElement day1emissionnode = doc.CreateElement(string.Empty, "Emission", string.Empty);
            day1node.AppendChild(day1emissionnode);
            XmlText day1emissiontextnode = doc.CreateTextNode(day1emission);
            day1emissionnode.AppendChild(day1emissiontextnode);


            //Max emission node day2
            XmlElement day2node = doc.CreateElement(string.Empty, "Day", string.Empty);
            maxemissionnode.AppendChild(day2node);
            XmlElement day2name = doc.CreateElement(string.Empty, "Name", string.Empty);
            day2node.AppendChild(day2name);
            XmlText day2nametext = doc.CreateTextNode(day2emisstionname);
            day2name.AppendChild(day2nametext);
            XmlElement day2datenode = doc.CreateElement(string.Empty, "Date", string.Empty);
            day2node.AppendChild(day2datenode);
            XmlText day2datetext = doc.CreateTextNode(dateday2);
            day2datenode.AppendChild(day2datetext);
            XmlElement day2emissionnode = doc.CreateElement(string.Empty, "Emission", string.Empty);
            day2node.AppendChild(day2emissionnode);
            XmlText day2emissiontextnode = doc.CreateTextNode(day2emission);
            day2emissionnode.AppendChild(day2emissiontextnode);


            //Max emission node day3
            XmlElement day3node = doc.CreateElement(string.Empty, "Day", string.Empty);
            maxemissionnode.AppendChild(day3node);
            XmlElement day3name = doc.CreateElement(string.Empty, "Name", string.Empty);
            day3node.AppendChild(day3name);
            XmlText day3nametext = doc.CreateTextNode(day3emisstionname);
            day3name.AppendChild(day3nametext);
            XmlElement day3datenode = doc.CreateElement(string.Empty, "Date", string.Empty);
            day3node.AppendChild(day3datenode);
            XmlText day3datetext = doc.CreateTextNode(dateday3);
            day3datenode.AppendChild(day3datetext);
            XmlElement day3emissionnode = doc.CreateElement(string.Empty, "Emission", string.Empty);
            day3node.AppendChild(day3emissionnode);
            XmlText day3emissiontextnode = doc.CreateTextNode(day3emission);
            day3emissionnode.AppendChild(day3emissiontextnode);

            //ActualHeatRates
            XmlElement actualheatratesnode = doc.CreateElement(string.Empty, "ActualHeatRates", string.Empty);
            rootnode.AppendChild(actualheatratesnode);

            XmlElement actualheatratenode = doc.CreateElement(string.Empty, "ActualHeatRate", string.Empty);
            actualheatratesnode.AppendChild(actualheatratenode);

            XmlElement actualheatratenamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            actualheatratenode.AppendChild(actualheatratenamenode);
            XmlText actualheatratenametest = doc.CreateTextNode("Coal[1]");
            actualheatratenamenode.AppendChild(actualheatratenametest);

            XmlElement actualheatratevaluenode = doc.CreateElement(string.Empty, "HeatRate", string.Empty);
            actualheatratenode.AppendChild(actualheatratevaluenode);
            XmlText actualheatratevalue = doc.CreateTextNode(Convert.ToString(heatrate));
            actualheatratevaluenode.AppendChild(actualheatratevalue);

            string putputpath = ConfigurationManager.AppSettings["outputPath"];
            doc.Save(putputpath + @"\output.xml");
        }
    }
}