﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BradyConsoleApp2
{
    public class XmlUtilities
    {
        List<string> windlist = new List<string>();
        List<string> gaslist = new List<string>();
        List<string> coallist = new List<string>();
        XmlDocument doc = new XmlDocument();
        public XmlUtilities() {
            doc.PreserveWhitespace = true;
            try
            {
                string path = ConfigurationManager.AppSettings["Path"];
                doc.Load(path + @"\01-Basic.xml");
            }
            catch (System.IO.FileNotFoundException)
            {
                Console.WriteLine("File not found!");
            }
        }
        public List<string> getWindValuesFromXml() {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Wind/WindGenerator");
       
            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    windlist.Add(node2.SelectSingleNode("Date").InnerText);
                    windlist.Add(node2.SelectSingleNode("Energy").InnerText);
                    windlist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            return windlist;
        }

        public List<string> getGasValuesFromXml()
        {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Gas/GasGenerator");

            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    gaslist.Add(node2.SelectSingleNode("Date").InnerText);
                    gaslist.Add(node2.SelectSingleNode("Energy").InnerText);
                    gaslist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            XmlNodeList emisions = doc.DocumentElement.SelectNodes("/GenerationReport/Gas/GasGenerator");
            foreach (XmlNode emision in emisions) {
                gaslist.Add(emision.SelectSingleNode("EmissionsRating").InnerText);
            }
            return gaslist;
        }

        public List<string> getCoalValuesFromXml()
        {
            XmlNodeList nodes = doc.DocumentElement.SelectNodes("/GenerationReport/Coal/CoalGenerator");

            foreach (XmlNode node in nodes)
            {
                XmlNodeList name = node.SelectNodes("Generation/Day");

                foreach (XmlNode node2 in name)
                {
                    coallist.Add(node2.SelectSingleNode("Date").InnerText);
                    coallist.Add(node2.SelectSingleNode("Energy").InnerText);
                    coallist.Add(node2.SelectSingleNode("Price").InnerText);
                }
            }
            XmlNodeList emisions = doc.DocumentElement.SelectNodes("/GenerationReport/Coal/CoalGenerator");
            foreach (XmlNode emision in emisions)
            {
                coallist.Add(emision.SelectSingleNode("EmissionsRating").InnerText);
                coallist.Add(emision.SelectSingleNode("TotalHeatInput").InnerText);
                coallist.Add(emision.SelectSingleNode("ActualNetGeneration").InnerText);
            }
            return coallist;
        }

        //11 param
        public void generateXmlFile(double totalwindoffshore, double totalwindonshore, double totalgas, double totalcoal, string day1emision, string day2emission, string day3emission, double heatrate, string dateday1, string dateday2, string dateday3)
        {
            string emissionname;
            Console.WriteLine(totalwindoffshore +"==="+ totalwindonshore + "===" + totalgas + "===" + totalcoal + "===" + day1emision + "===" + day2emission + "===" + day3emission + "===" + heatrate);
            
            XmlDocument doc = new XmlDocument();

            if (day1emision.Contains("gas")){
                emissionname = "Gas[1]";
                day1emision = day1emision.Substring(day1emision.Length - 3);
            }
            else{
                emissionname = "Coal[1]";
            }

            if (day2emission.Contains("gas"))
            {
                emissionname = "Gas[1]";
                day2emission = day2emission.Substring(day2emission.Length - 3);
            }
            else
            {
                emissionname = "Coal[1]";
            }

            if (day3emission.Contains("gas"))
            {
                emissionname = "Gas[1]";
                day3emission = day3emission.Substring(day3emission.Length - 3);
            }
            else
            {
                emissionname = "Coal[1]";
            }





            //(1) the xml declaration is recommended, but not mandatory
            XmlDeclaration xmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            XmlElement root = doc.DocumentElement;
            doc.InsertBefore(xmlDeclaration, root);

            //Root node
            XmlElement rootnode = doc.CreateElement(string.Empty, "GenerationOutput", string.Empty);
            doc.AppendChild(rootnode);

            XmlElement totalsnode = doc.CreateElement(string.Empty, "Totals", string.Empty);
            rootnode.AppendChild(totalsnode);

            //winoffshore generator 
            XmlElement generatornode1 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode1);

            XmlElement windoffnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode1.AppendChild(windoffnamenode);
            XmlText namewinoffshore = doc.CreateTextNode("Wind[Offshore]");
            windoffnamenode.AppendChild(namewinoffshore);
            
            XmlElement windofftotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode1.AppendChild(windofftotalnode);
            XmlText valuewindoffshore = doc.CreateTextNode(Convert.ToString(totalwindoffshore));
            windofftotalnode.AppendChild(valuewindoffshore);

            //winonshore generator
            XmlElement generatornode2 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode2);

            XmlElement windonnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode2.AppendChild(windonnamenode);
            XmlText namewinonshore = doc.CreateTextNode("Wind[Onshore]");
            windonnamenode.AppendChild(namewinonshore);

            XmlElement wintonotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode2.AppendChild(wintonotalnode);
            XmlText valuewinonshore = doc.CreateTextNode(Convert.ToString(totalwindonshore));
            wintonotalnode.AppendChild(valuewinonshore);

            //gas generator
            XmlElement generatornode3 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode3);

            XmlElement gasnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode3.AppendChild(gasnamenode);
            XmlText namegas = doc.CreateTextNode("Gas[1]");
            gasnamenode.AppendChild(namegas);

            XmlElement gastotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode3.AppendChild(gastotalnode);
            XmlText valuegas = doc.CreateTextNode(Convert.ToString(totalgas));
            gastotalnode.AppendChild(valuegas);

            //coal generator 
            XmlElement generatornode4 = doc.CreateElement(string.Empty, "Generator", string.Empty);
            totalsnode.AppendChild(generatornode4);

            XmlElement coalnamenode = doc.CreateElement(string.Empty, "Name", string.Empty);
            generatornode4.AppendChild(coalnamenode);
            XmlText namecoal = doc.CreateTextNode("Coal[1]");
            coalnamenode.AppendChild(namecoal);

            XmlElement coaltotalnode = doc.CreateElement(string.Empty, "Total", string.Empty);
            generatornode4.AppendChild(coaltotalnode);
            XmlText valuecoal = doc.CreateTextNode(Convert.ToString(totalcoal));
            coaltotalnode.AppendChild(valuecoal);

            
            XmlElement maxemissionnode = doc.CreateElement(string.Empty, "MaxEmissionGenerators", string.Empty);
            rootnode.AppendChild(maxemissionnode);

            //Max emission node day1
            XmlElement day1node = doc.CreateElement(string.Empty, "Day", string.Empty);
            maxemissionnode.AppendChild(day1node);
            XmlText day1name = doc.CreateTextNode(emissionname);
            day1node.AppendChild(day1name);
            XmlText day1date = doc.CreateTextNode(dateday1);
            day1node.AppendChild(day1date);
            XmlText day1emissiontext = doc.CreateTextNode(day1emision);
            day1node.AppendChild(day1emissiontext);

            //Max emission node day2
            XmlElement day2node = doc.CreateElement(string.Empty, "Day", string.Empty);
            maxemissionnode.AppendChild(day2node);
            XmlText day2name = doc.CreateTextNode(emissionname);
            day2node.AppendChild(day2name);
            XmlText day2date = doc.CreateTextNode(dateday2);
            day2node.AppendChild(day2date);
            XmlText day2emissiontext = doc.CreateTextNode(day2emission);
            day2node.AppendChild(day2emissiontext);

            
            //Max emission node day3
            XmlElement day3node = doc.CreateElement(string.Empty, "Day", string.Empty);
            maxemissionnode.AppendChild(day3node);
            XmlText day3name = doc.CreateTextNode(emissionname);
            day3node.AppendChild(day3name);
            XmlText day3date = doc.CreateTextNode(dateday3);
            day3node.AppendChild(day2date);
            XmlText day3emissiontext = doc.CreateTextNode(day3emission);
            day3node.AppendChild(day3emissiontext);

            doc.Save(@"D:\Vizrt Work Folder\Installer\2022\April 2022\April 29\output.xml");
        }
    }
}