﻿using System.IO;  // include the System.IO namespace
using System.Text;
using System.Xml;
using static BradyConsoleApp2.FolderWatcher;

namespace BradyConsoleApp2
{
    class Program
    {

        public struct References 
        {
            public const double offshorewindlow = 0.265;
            public const double onshorewindhigh = 0.946;
            public const double gasmedium = 0.696;
            public const double gasmediumemision = 0.562;
            public const double coalhighemision = 0.812;
            public const double coalmedium = 0.696;
            // Add Remaining units / values
        }
        static void Main(string[] args)
        {
            FolderWatcher watcher = new FolderWatcher();
            watcher.getLatestFileFromWatchedFolder();
        }
    }
}


