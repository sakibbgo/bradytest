﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BradyConsoleApp2
{
    public class ValueProcessor
    {
        public ValueProcessor() { 
        
        }
        public double getTotalGenerationPerDay(double price, double energy, double valuefactor) {
            return price * energy * valuefactor;
        }
    }
}
