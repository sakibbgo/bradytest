﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BradyConsoleApp2.Program;

namespace BradyConsoleApp2
{
    public class FolderWatcher
    {
        private List<string> getwindlist = new List<string>();
        private List<string> getgaslist = new List<string>();
        private List<string> getcoallist = new List<string>();
        private double totalwindoffshore;
        private double totalwindonshore;
        private double totalgas;
        private double totalcoal;
        public void getLatestFileFromWatchedFolder() {
            string path = ConfigurationManager.AppSettings["Path"];
            using var watcher = new FileSystemWatcher(@path);
            //Properties used for monitoring changes
            watcher.NotifyFilter = NotifyFilters.Attributes
                                 | NotifyFilters.CreationTime
                                 | NotifyFilters.DirectoryName
                                 | NotifyFilters.FileName
                                 | NotifyFilters.LastWrite
                                 | NotifyFilters.Security
                                 | NotifyFilters.Size;

            //Event for monitoring on creation
            watcher.Created += OnCreated;

            //Searching for that specific file for monitoring 
            watcher.Filter = "01-Basic.xml";

            watcher.IncludeSubdirectories = false;
            watcher.EnableRaisingEvents = true;

            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();

            void OnCreated(object sender, FileSystemEventArgs e)
            {
                XmlUnilities xmlUnilities = new XmlUnilities();
                getwindlist = xmlUnilities.getWindValuesFromXml();
                getgaslist = xmlUnilities.getGasValuesFromXml();
                getcoallist = xmlUnilities.getCoalValuesFromXml();
                int windkey = 0;
                int gaskey = 0;
                int coalkey = 0;
                Dictionary<int, string> winddic = new Dictionary<int, string>();
                Dictionary<int, string> gasdic = new Dictionary<int, string>();
                Dictionary<int, string> coaldic = new Dictionary<int, string>();
                foreach (string wind in getwindlist)
                {
                    windkey++;
                    winddic.Add(windkey, wind);                  
                }

                foreach (string gas in getgaslist)
                {
                    gaskey++;
                    gasdic.Add(gaskey, gas);
                }

                foreach (string coal in getcoallist)
                {
                    coalkey++;
                    coaldic.Add(coalkey, coal);
                }
                ValueProcessor processor = new ValueProcessor();
                totalwindoffshore = processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[3]), Convert.ToDouble(winddic[2]), References.offshorewindlow) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[6]), Convert.ToDouble(winddic[5]), References.offshorewindlow) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[9]), Convert.ToDouble(winddic[8]), References.offshorewindlow);

                totalwindonshore = processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[12]), Convert.ToDouble(winddic[11]), References.onshorewindhigh) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[15]), Convert.ToDouble(winddic[14]), References.onshorewindhigh) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[18]), Convert.ToDouble(winddic[17]), References.onshorewindhigh);

                totalgas = processor.getTotalGenerationPerDay(Convert.ToDouble(gasdic[3]), Convert.ToDouble(gasdic[2]), References.gasmedium) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(gasdic[6]), Convert.ToDouble(gasdic[5]), References.gasmedium) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(gasdic[9]), Convert.ToDouble(gasdic[8]), References.gasmedium);

                totalcoal = processor.getTotalGenerationPerDay(Convert.ToDouble(coaldic[3]), Convert.ToDouble(coaldic[2]), References.coalmedium) +
                            processor.getTotalGenerationPerDay(Convert.ToDouble(coaldic[6]), Convert.ToDouble(coaldic[5]), References.coalmedium) +
                            processor.getTotalGenerationPerDay(Convert.ToDouble(coaldic[9]), Convert.ToDouble(coaldic[8]), References.coalmedium);
                Console.WriteLine("Total Offshorewind: "+totalwindoffshore+" Total Onshorewind: "+totalwindonshore+" Total gas: "+totalgas+" Total coal: "+totalcoal);
            }
        }
    }
}
