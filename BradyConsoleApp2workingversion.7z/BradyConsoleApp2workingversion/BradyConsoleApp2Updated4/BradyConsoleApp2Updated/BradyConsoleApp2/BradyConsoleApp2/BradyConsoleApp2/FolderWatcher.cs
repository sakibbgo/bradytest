﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BradyConsoleApp2.Program;

namespace BradyConsoleApp2
{
    public class FolderWatcher
    {
        private List<string> getwindlist = new List<string>();
        private List<string> getgaslist = new List<string>();
        private List<string> getcoallist = new List<string>();
        private double totalwindoffshore;
        private double totalwindonshore;
        private double totalgas;
        private double totalcoal;
        private double dailygasemissionday1;
        private double dailygasemissionday2;
        private double dailygasemissionday3;
        private double dailycoalemissionday1;
        private double dailycoalemissionday2;
        private double dailycoalemissionday3;

        private double highestdailyemissionday1;
        private double highestdailyemissionday2;
        private double highestdailyemissionday3;
        private string highestdailyemissionday1withtag;
        private string highestdailyemissionday2withtag;
        private string highestdailyemissionday3withtag;
        private double actualheatrate;
        private Boolean gasday1;
        private Boolean gasday2;
        private Boolean gasday3;

        public void generateXmlFileFromWatchedFolder() {
            string path = ConfigurationManager.AppSettings["Path"];
            using var watcher = new FileSystemWatcher(@path);
            //Properties used for monitoring changes
            watcher.NotifyFilter = NotifyFilters.Attributes
                                 | NotifyFilters.CreationTime
                                 | NotifyFilters.DirectoryName
                                 | NotifyFilters.FileName
                                 | NotifyFilters.LastWrite
                                 | NotifyFilters.Security
                                 | NotifyFilters.Size;

            //Event for monitoring on creation
            watcher.Created += OnCreated;

            //Searching for that specific file for monitoring 
            watcher.Filter = "01-Basic.xml";

            watcher.IncludeSubdirectories = false;
            watcher.EnableRaisingEvents = true;

            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();

            void OnCreated(object sender, FileSystemEventArgs e)
            {
                XmlUtilities xmlUtilities = new XmlUtilities();
                getwindlist = xmlUtilities.getWindValuesFromXml();
                getgaslist = xmlUtilities.getGasValuesFromXml();
                getcoallist = xmlUtilities.getCoalValuesFromXml();
                int windkey = 0;
                int gaskey = 0;
                int coalkey = 0;
                Dictionary<int, string> winddic = new Dictionary<int, string>();
                Dictionary<int, string> gasdic = new Dictionary<int, string>();
                Dictionary<int, string> coaldic = new Dictionary<int, string>();
                foreach (string wind in getwindlist)
                {
                    windkey++;
                    winddic.Add(windkey, wind);                  
                }

                foreach (string gas in getgaslist)
                {
                    gaskey++;
                    gasdic.Add(gaskey, gas);
                }

                foreach (string coal in getcoallist)
                {
                    coalkey++;
                    coaldic.Add(coalkey, coal);
                }
                ValueProcessor processor = new ValueProcessor();
                totalwindoffshore = processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[3]), Convert.ToDouble(winddic[2]), References.offshorewindlow) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[6]), Convert.ToDouble(winddic[5]), References.offshorewindlow) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[9]), Convert.ToDouble(winddic[8]), References.offshorewindlow);

                totalwindonshore = processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[12]), Convert.ToDouble(winddic[11]), References.onshorewindhigh) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[15]), Convert.ToDouble(winddic[14]), References.onshorewindhigh) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(winddic[18]), Convert.ToDouble(winddic[17]), References.onshorewindhigh);

                totalgas = processor.getTotalGenerationPerDay(Convert.ToDouble(gasdic[3]), Convert.ToDouble(gasdic[2]), References.gasmedium) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(gasdic[6]), Convert.ToDouble(gasdic[5]), References.gasmedium) +
                           processor.getTotalGenerationPerDay(Convert.ToDouble(gasdic[9]), Convert.ToDouble(gasdic[8]), References.gasmedium);

                totalcoal = processor.getTotalGenerationPerDay(Convert.ToDouble(coaldic[3]), Convert.ToDouble(coaldic[2]), References.coalmedium) +
                            processor.getTotalGenerationPerDay(Convert.ToDouble(coaldic[6]), Convert.ToDouble(coaldic[5]), References.coalmedium) +
                            processor.getTotalGenerationPerDay(Convert.ToDouble(coaldic[9]), Convert.ToDouble(coaldic[8]), References.coalmedium);
                //Console.WriteLine("Total Offshorewind: "+totalwindoffshore+" Total Onshorewind: "+totalwindonshore+" Total gas: "+totalgas+" Total coal: "+totalcoal);


                dailygasemissionday1 = processor.getTotalEmissionPerday(Convert.ToDouble(gasdic[2]), Convert.ToDouble(gasdic[10]), References.gasmediumemision);
                dailygasemissionday2 = processor.getTotalEmissionPerday(Convert.ToDouble(gasdic[5]), Convert.ToDouble(gasdic[10]), References.gasmediumemision);
                dailygasemissionday3 = processor.getTotalEmissionPerday(Convert.ToDouble(gasdic[8]), Convert.ToDouble(gasdic[10]), References.gasmediumemision);

                dailycoalemissionday1 = processor.getTotalEmissionPerday(Convert.ToDouble(coaldic[2]), Convert.ToDouble(coaldic[10]), References.coalhighemision);
                dailycoalemissionday2 = processor.getTotalEmissionPerday(Convert.ToDouble(coaldic[5]), Convert.ToDouble(coaldic[10]), References.coalhighemision);
                dailycoalemissionday3 = processor.getTotalEmissionPerday(Convert.ToDouble(coaldic[8]), Convert.ToDouble(coaldic[10]), References.coalhighemision);

                double result = (dailygasemissionday1 > dailycoalemissionday1) ? (highestdailyemissionday1 = dailygasemissionday1) : highestdailyemissionday1 = dailycoalemissionday1;
                string tagname = (dailygasemissionday1 > dailycoalemissionday1) ? highestdailyemissionday1withtag = Convert.ToString(highestdailyemissionday1)+"gas" : highestdailyemissionday1withtag = Convert.ToString(highestdailyemissionday1);
               
                result = (dailygasemissionday2 > dailycoalemissionday2) ? highestdailyemissionday2 = dailygasemissionday2 : highestdailyemissionday2 = dailycoalemissionday2;
                tagname = (dailygasemissionday2 > dailycoalemissionday2) ? highestdailyemissionday2withtag = Convert.ToString(highestdailyemissionday2) + "gas" : highestdailyemissionday2withtag = Convert.ToString(highestdailyemissionday2);

                result = (dailygasemissionday3 > dailycoalemissionday3) ? highestdailyemissionday3 = dailygasemissionday3 : highestdailyemissionday3 = dailycoalemissionday3;
                tagname = (dailygasemissionday3 > dailycoalemissionday3) ? highestdailyemissionday3withtag = Convert.ToString(highestdailyemissionday3) + "gas" : highestdailyemissionday3withtag = Convert.ToString(highestdailyemissionday3);

                actualheatrate = Convert.ToDouble(coaldic[11]) / Convert.ToDouble(coaldic[12]);

                xmlUtilities.generateXmlFile(totalwindoffshore, totalwindonshore, totalgas, totalcoal, highestdailyemissionday1withtag, highestdailyemissionday2withtag, highestdailyemissionday3withtag, actualheatrate, gasdic[1], gasdic[4], gasdic[7]);
            }
        }
    }
}
